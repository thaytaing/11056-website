#Navigation Bar

The navigation bar contains four different functions that include home page, contact page, festivals page and booking page.

- Home Page - Description about the Canberra Art Biennial Sponsors that also list the popular events
- Contact Us Page - To leave the special request about event booking
- Festivals - List the festival timetable and prices
- Donation Page - Donate to the festival 


# Festival function

We made assumption for the maximum number of visitors in each festival.


#Footer 

The designed footer consider the Canberra Art Festivals 

#Mobile Friendly

This project consider the multiple devices with different screen size. 